package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.dto.AuthResponseDto;
import com.cts.dto.LoginRequestDto;
import com.cts.dto.UserRequestDto;
import com.cts.dto.UserResponseDto;
import com.cts.service.AuthService;

import jakarta.validation.Valid;

@RestController
public class AuthController {

	@Autowired
	AuthService authService;
	
	@PostMapping("/signup")
	public ResponseEntity<UserResponseDto> createUser(@Valid @RequestBody UserRequestDto userRequestDto){
		UserResponseDto userResponseDto = authService.createUser(userRequestDto);
		return new ResponseEntity<>(userResponseDto, HttpStatus.CREATED);
	}
	
	@PostMapping("/login")
	public ResponseEntity<AuthResponseDto> loginUser(@Valid @RequestBody LoginRequestDto loginRequestDto){
		AuthResponseDto authResponseDto = authService.verify(loginRequestDto);
		
		if (authResponseDto.getToken() != null) {
			return new ResponseEntity<>(authResponseDto, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(authResponseDto, HttpStatus.UNAUTHORIZED);
		}
	}
	
	@GetMapping("/hello")
	public String sayHello() {
		return "Hello";
	}
}

