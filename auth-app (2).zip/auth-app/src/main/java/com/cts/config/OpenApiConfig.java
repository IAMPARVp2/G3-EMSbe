package com.cts.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        // 1. Define the security scheme
        final String securitySchemeName = "bearerAuth";
        SecurityScheme securityScheme = new SecurityScheme()
            .name(securitySchemeName)
            .type(SecurityScheme.Type.HTTP) // Type is HTTP
            .scheme("bearer")               // Scheme is "bearer"
            .bearerFormat("JWT");           // Format is "JWT"

        // 2. Define the security requirement
        SecurityRequirement securityRequirement = new SecurityRequirement()
            .addList(securitySchemeName);

        return new OpenAPI()
            .info(new Info().title("Your API Title").version("1.0"))
            // 3. Add the components (security scheme)
            .components(new Components()
                .addSecuritySchemes(securitySchemeName, securityScheme)
            )
            // 4. Add the security requirement (the lock) globally to all endpoints
            .addSecurityItem(securityRequirement);
    }
}