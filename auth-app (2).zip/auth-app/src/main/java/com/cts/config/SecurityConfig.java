package com.cts.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

// --- IMPORT THESE ---
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.Collections;
// --------------------

@Configuration
@EnableWebSecurity
public class SecurityConfig {
    @Autowired
    private UserDetailsService userDetailsService;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
                // Add CORS configuration
                .cors(customizer -> customizer.disable()) // [!code ++]
                .csrf(customizer -> customizer.disable())
                .authorizeHttpRequests(request -> request
                        // --- NEW: Allow Swagger endpoints ---
                        .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                        .requestMatchers("/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html").permitAll() // [!code ++]
                        // --- Keep existing public endpoints ---
                        .requestMatchers("/auth/login", "/auth/signup", "/auth/hello").permitAll()
                        .requestMatchers("/login", "/signup", "/hello").permitAll()
                        .anyRequest().authenticated())
                .sessionManagement(session -> session
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12);
    }

    @Bean
    public AuthenticationProvider authenticationProvider(PasswordEncoder passwordEncoder) {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setPasswordEncoder(passwordEncoder);
        provider.setUserDetailsService(userDetailsService);
        return provider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    // ** ADD THIS NEW BEAN FOR CORS **
    @Bean
    public CorsConfigurationSource corsConfigurationSource() { // [!code ++]
        final CorsConfiguration configuration = new CorsConfiguration(); // [!code ++]
        // Allow requests from any origin
        configuration.setAllowedOrigins(Collections.singletonList("*")); // [!code ++]
        // Allow all standard HTTP methods
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS")); // [!code ++]
        // Allow all headers
        configuration.setAllowedHeaders(Collections.singletonList("*")); // [!code ++]
        final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource(); // [!code ++]
        // Apply this configuration to all paths
        source.registerCorsConfiguration("/**", configuration); // [!code ++]
        return source; // [!code ++]
    }
}
