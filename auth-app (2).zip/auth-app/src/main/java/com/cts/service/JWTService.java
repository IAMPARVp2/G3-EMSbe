package com.cts.service;

import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Collection; // [!code ++]
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors; // [!code ++]

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority; // [!code ++]
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import java.util.function.Function;

@Service
public class JWTService {
	@Value("${jwt.secret}")
	private String sk;

	// Update the signature to accept UserDetails
	public String generateToken(UserDetails userDetails) { // [!code ++]

		Map<String, Object> claims = new HashMap<>();

		// --- ADD ROLES TO TOKEN ---
		// Get authorities (roles) from UserDetails
		Collection<? extends GrantedAuthority> roles = userDetails.getAuthorities(); // [!code ++]
		// Add the roles as a claim. We just get the first one, assuming one role per user.
		if (!roles.isEmpty()) { // [!code ++]
			// We store just the string (e.g., "ADMIN", "CUSTOMER")
			String role = roles.iterator().next().getAuthority(); // [!code ++]
			claims.put("role", role); // [!code ++]
		}
		// --------------------------

		return Jwts.builder()
				.claims(claims) // Add the custom claims (with role)
				.subject(userDetails.getUsername()) // Use the username from UserDetails
				.issuedAt(new Date(System.currentTimeMillis()))
				.expiration(new Date(System.currentTimeMillis() + 1000 * 60 * 30))
				.signWith(getKey())
				.compact();
	}

	private SecretKey getKey() {
		byte[] keyBytes = Decoders.BASE64.decode(sk);
		return Keys.hmacShaKeyFor(keyBytes);
	}

	public String extractUserName(String token) {
		return extractClaim(token, Claims::getSubject);
	}

	private <T> T extractClaim(String token, Function<Claims, T> claimResolver) {
		final Claims claims = extractAllClaims(token);
		return claimResolver.apply(claims);
	}

	private Claims extractAllClaims(String token) {
		return Jwts.parser().verifyWith(getKey()).build().parseSignedClaims(token).getPayload();
	}

	public boolean validateToken(String token, UserDetails userDetails) {
		final String userName = extractUserName(token);
		return (userName.equals(userDetails.getUsername()) && !isTokenExpired(token));
	}

	private boolean isTokenExpired(String token) {
		return extractExpiration(token).before(new Date());
	}

	private Date extractExpiration(String token) {
		return extractClaim(token, Claims::getExpiration);
	}
}