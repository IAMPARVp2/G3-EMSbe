package com.cts.service;

import org.springframework.stereotype.Service;

import com.cts.dto.AuthResponseDto;
import com.cts.dto.LoginRequestDto;
import com.cts.dto.UserRequestDto;
import com.cts.dto.UserResponseDto;

@Service
public interface AuthService {
	
	public UserResponseDto createUser(UserRequestDto userRequestDto);

	public AuthResponseDto verify(LoginRequestDto loginRequestDto);
}
