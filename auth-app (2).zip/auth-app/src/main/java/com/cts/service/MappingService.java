package com.cts.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dto.LoginRequestDto;
import com.cts.dto.UserRequestDto;
import com.cts.dto.UserResponseDto;
import com.cts.entity.User;

@Service
public class MappingService {

    @Autowired
    private ModelMapper modelMapper;

    public User convertToEntity(UserRequestDto userRequestDto) {
        return modelMapper.map(userRequestDto, User.class);
    }

    public UserResponseDto convertToResponseDto(User user) {
        return modelMapper.map(user, UserResponseDto.class);
    }

    public User convertLoginToEntity(LoginRequestDto loginRequestDto) {
        return modelMapper.map(loginRequestDto, User.class);
    }
}
