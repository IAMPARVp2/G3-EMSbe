package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cts.dto.AuthResponseDto;
import com.cts.dto.LoginRequestDto;
import com.cts.dto.UserRequestDto;
import com.cts.dto.UserResponseDto;
import com.cts.entity.User;
import com.cts.exceptions.OrganizerException;
import com.cts.repository.UserRepository;

@Service
public class AuthServiceImpl implements AuthService {

	@Autowired
	UserRepository uRepo;
	@Autowired
	AuthenticationManager authManager;
	@Autowired
	JWTService jwtService;
	@Autowired
	private PasswordEncoder encoder;
	@Autowired
	private MappingService mappingService;

	public UserResponseDto createUser(UserRequestDto userRequestDto) {
		// Convert DTO to Entity
		User user = mappingService.convertToEntity(userRequestDto);
		
		// If client did not supply status, default to ACTIVE
		if (user.getStatus() == null || user.getStatus().isBlank()) {
			user.setStatus("ACTIVE");
		}
		
		// Encode password
		user.setPassword(encoder.encode(user.getPassword()));
		
		// Check if email already exists
		if (uRepo.findByEmail(user.getEmail()) != null) {
			throw new OrganizerException("Email already exist:500");
		}
		
		// Save user
		User savedUser = uRepo.save(user);
		
		// Convert back to DTO and return
		return mappingService.convertToResponseDto(savedUser);
	}

	public AuthResponseDto verify(LoginRequestDto loginRequestDto) {
		try {
			// Convert DTO to Entity for authentication
			User user = mappingService.convertLoginToEntity(loginRequestDto);
			
			Authentication authentication = authManager.authenticate(
					new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword())
			);

			if (authentication.isAuthenticated()) {
				// Get the authenticated principal (our UserPrincipal object)
				UserDetails userDetails = (UserDetails) authentication.getPrincipal();
				
				// Generate the token using the userDetails
				String token = jwtService.generateToken(userDetails);
				
				// Get user from database and convert to DTO
				User authenticatedUser = uRepo.findByEmail(user.getEmail());
				UserResponseDto userResponseDto = mappingService.convertToResponseDto(authenticatedUser);
				
				// Return response DTO with token and user info
				return new AuthResponseDto(token, "Authentication successful", userResponseDto);
			} else {
				return new AuthResponseDto(null, "Authentication failed", null);
			}
		} catch (AuthenticationException e) {
			return new AuthResponseDto(null, "Authentication failed: Invalid username or password", null);
		}
	}
}