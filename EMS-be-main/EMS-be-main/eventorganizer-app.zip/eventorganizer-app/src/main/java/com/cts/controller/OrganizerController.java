package com.cts.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.entity.Organizer;
import com.cts.entity.User;
import com.cts.service.OrganizerService;

@RestController
@RequestMapping("/organizer")
public class OrganizerController {

	@Autowired
	OrganizerService oService;

	@PostMapping("/signup")
	public ResponseEntity<User> addOrganizer(@RequestBody User orgUser) {
		orgUser.setRole("Organizer");
		orgUser = oService.addOrganizer(orgUser);
		return new ResponseEntity<User>(orgUser, HttpStatus.OK);
	}

	@GetMapping
	public ResponseEntity<List<User>> getAll() {
		List<User> list = oService.getAll();
		return new ResponseEntity<List<User>>(list, HttpStatus.OK);

	}

	@PostMapping("/organizerProfile/{email}")
	public ResponseEntity<Organizer> addOrgnaizerProfile(@RequestBody Organizer organizerProfile,
			@PathVariable String email) {
		organizerProfile = oService.addOrganizerProfile(organizerProfile, email);
		return new ResponseEntity<Organizer>(organizerProfile, HttpStatus.OK);
	}

	@PatchMapping("/{id}")
	public ResponseEntity<User> patchUser(@PathVariable int id, @RequestBody Map<String, String> updates) {
		User updatedUser = oService.patchUser(id, updates);
		return new ResponseEntity<>(updatedUser, HttpStatus.OK);
	}
}
