package com.cts.exceptions;

public class OrganizerException extends RuntimeException {
	public OrganizerException(String message) {
		super(message);
	}
}
